# Changelog — v98.63.9.21

- Tools menu now follows the supplied reference recording: category headings and a responsive three-column tile layout.
- All 16 existing tool destinations remain present and are still opened through the same delegated navigation handler.
- Unit Converter now starts with a 3-column category chooser. Choosing a category reveals the existing conversion workspace; “All categories” returns to the chooser.
- Fixed duplicate `sci-shift-toggle` ID; the INV control remains in the scientific 4×4 function grid.
- Added automated regression tests for the new UI and interaction paths.
- INV now behaves as a one-shot secondary-function modifier and restores primary key labels after an inverse function is inserted.
