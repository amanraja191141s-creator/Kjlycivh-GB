# Release verification — v98.63.9.30


- Release identity: `1.98.77-v98.63.9.30`
- Android versionCode: `1098078`
- scientific `+`/More key and secondary panel removed.
- INV mappings across all applicable pairs verified by test suite.
- Basic keypad height/basis reduced by 20px during scientific drawer display.
- Scientific labels use 20px baseline.
- Web bundle build and 38 automated release tests passed.
- Workflow file validated; root workflow and standalone workflow are byte-identical.
- ZIP integrity passed.
- Actual APK build/install/touch verification pending CI/device.
