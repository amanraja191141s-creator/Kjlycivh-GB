# v98.63.9.27 — Final video-reference corrections

- Scientific function panel consolidated to a 4×4 pink reference layout with legible labels, no competing card/border styling, and safe wrapping.
- Expanded scientific functions use a 4×4 matching pink overlay, bounded to the panel, with its own scroll and close control.
- Tools catalogue uses one scroll owner and reduced bottom padding; cards and labels can grow without clipping.
- Updated package/PWA/Android version identity and service-worker cache namespace.
- Added regression tests for scientific panel, expanded options and Tools overflow.
- Automated release tests pass and web bundle builds. Android APK compilation and physical device validation remain pending.
