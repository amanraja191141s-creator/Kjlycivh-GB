# Micro Audit — v98.63.9.30 CI Hotfix

## Failure
Workflow expected the old `v9863929-scientific-key-size-video-reference` cache marker, while `service-worker.js` declares the v30 namespace `v9863930-scientific-inverse-all-keys-no-more-20px`. This stops source verification before Android SDK, npm, regression, Capacitor or Gradle.

## Fix
- Extract CACHE from selected source worker dynamically.
- Require generated `www/service-worker.js` to exist and contain the source namespace.
- Remove hardcoded obsolete marker.
- Synchronize duplicate workflows.
- Add regression test to `test:release`.

## Scope
No runtime/UI code changes. Version remains v98.63.9.30.

## Additional source-gate mismatch
Workflow required `tests/v98634-marked-calculator-boundary.test.mjs`, but project contains `tests/v98634-marked-screenshot-cleanup.test.mjs`. The workflow required-file list was corrected to the existing test file, and a regression assertion now verifies that path.
