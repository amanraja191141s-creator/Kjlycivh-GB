import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');

test('scientific keypad is nested inside calculator, not a standalone screen', () => {
  assert.match(html, /<section class="scientific-screen scientific-drawer" id="screen-scientific"/);
  assert.match(html, /id="screen-calc"[\s\S]*?<section class="scientific-screen scientific-drawer" id="screen-scientific"/);
  assert.doesNotMatch(html, /class="screen scientific-screen"/);
});
test('scientific calculator is removed from Tools catalog', () => {
  assert.doesNotMatch(html, /data-tool-screen="scientific"/);
  assert.doesNotMatch(html, /Scientific Calculator<\/span>/);
});
test('edge swipe opens and reverse swipe closes the scientific drawer', () => {
  assert.match(js, /x >= width - 34/);
  assert.match(js, /if \(!start\.open && dx < 0\) openDrawer\(\)/);
  assert.match(js, /else if \(start\.open && dx > 0\) closeDrawer\(false\)/);
  assert.match(js, /pointerup/);
});
test('drawer has close and Escape access paths plus correct accessibility state', () => {
  assert.match(html, /id="sci-drawer-close"/);
  assert.match(js, /event\.key === 'Escape' && drawerOpen/);
  assert.match(js, /screen\.setAttribute\('aria-hidden', 'false'\)/);
  assert.match(js, /screen\.inert = true/);
});
test('drawer keeps scientific controls and responsive themed layout', () => {
  for (const token of ['data-sci-insert="sin("','data-sci-insert="cos("','data-sci-insert="sqrt("','data-sci-memory="MS"','data-sci-action="equals"']) assert.ok(html.includes(token), token);
  assert.match(css, /scientific-drawer\.is-open/);
  assert.match(css, /prefers-reduced-motion:reduce/);
  assert.match(css, /scientific-function-grid[^}]*grid-template-columns:\s*repeat\(4/);
});
